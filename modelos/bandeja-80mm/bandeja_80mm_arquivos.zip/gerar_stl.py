"""Parametric rounded rectangular tray / open frame. All dimensions in mm.
Python dependencies: numpy, scipy, trimesh, networkx, matplotlib.
"""
import sys
sys.path.insert(0, '/workspace/scratch/stl-tools')
import argparse
from pathlib import Path
import json
import numpy as np
import trimesh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from zipfile import ZipFile, ZIP_DEFLATED

parser=argparse.ArgumentParser()
parser.add_argument('--sem-fundo', action='store_true')
args=parser.parse_args()
OUT=Path(__file__).resolve().parent
LENGTH=80.0; WIDTH=25.0; HEIGHT=10.0
WALL=3.0; BASE=0.0 if args.sem_fundo else 2.0
RADIUS=4.0; EDGE=0.6; STEPS=48; FILLET_STEPS=10
name='moldura' if args.sem_fundo else 'bandeja'

def contour(length,width,radius,z):
    pts=[]
    for cx,cy,start in [(length/2-radius,width/2-radius,0),
                        (-length/2+radius,width/2-radius,np.pi/2),
                        (-length/2+radius,-width/2+radius,np.pi),
                        (length/2-radius,-width/2+radius,3*np.pi/2)]:
        for a in np.linspace(start,start+np.pi/2,STEPS+1):
            pts.append([cx+radius*np.cos(a),cy+radius*np.sin(a),z])
    return np.asarray(pts)

rings=[]
def outer(inset,z):
    rings.append(contour(LENGTH-2*inset,WIDTH-2*inset,RADIUS-inset,z))
def inner(outset,z):
    rings.append(contour(LENGTH-2*WALL+2*outset,WIDTH-2*WALL+2*outset,RADIUS-WALL+outset,z))
# Rounded lower outer edge: flat bottom to vertical side wall.
for a in np.linspace(0,np.pi/2,FILLET_STEPS+1):
    outer(EDGE*(1-np.sin(a)),EDGE*(1-np.cos(a)))
outer(0,HEIGHT-EDGE)
# Rounded upper outer edge.
for a in np.linspace(0,np.pi/2,FILLET_STEPS+1)[1:]:
    outer(EDGE*(1-np.cos(a)),HEIGHT-EDGE+EDGE*np.sin(a))
# Top rim connects outer top to inner top.
inner(EDGE,HEIGHT)
# Rounded upper inner edge.
for a in np.linspace(0,np.pi/2,FILLET_STEPS+1)[1:]:
    inner(EDGE*(1-np.sin(a)),HEIGHT-EDGE+EDGE*np.cos(a))
if BASE:
    inner(0,BASE+EDGE)
    # Rounded junction from inner vertical wall to the horizontal floor.
    for a in np.linspace(0,np.pi/2,FILLET_STEPS+1)[1:]:
        inner(-EDGE*(1-np.cos(a)),BASE+EDGE-EDGE*np.sin(a))
else:
    inner(0,EDGE)
    for a in np.linspace(0,np.pi/2,FILLET_STEPS+1)[1:]:
        inner(EDGE*(1-np.cos(a)),EDGE-EDGE*np.sin(a))

n=len(rings[0]); vertices=np.concatenate(rings).tolist(); faces=[]
for r in range(len(rings)-1):
    a=r*n;b=(r+1)*n
    for i in range(n):
        j=(i+1)%n
        faces.extend([[a+i,a+j,b+j],[a+i,b+j,b+i]])
if BASE:
    bottom_center=len(vertices); vertices.append([0,0,0])
    floor_center=len(vertices); vertices.append([0,0,BASE])
    last=(len(rings)-1)*n
    for i in range(n):
        j=(i+1)%n
        faces.extend([[bottom_center,j,i],[floor_center,last+i,last+j]])
else:
    last=(len(rings)-1)*n
    for i in range(n):
        j=(i+1)%n
        faces.extend([[last+i,last+j,j],[last+i,j,i]])
mesh=trimesh.Trimesh(vertices=np.asarray(vertices),faces=np.asarray(faces),process=True)
assert mesh.is_watertight and mesh.is_winding_consistent and mesh.is_volume
assert len(mesh.split())==1
assert np.allclose(mesh.extents,[LENGTH,WIDTH,HEIGHT],atol=1e-7)
assert mesh.euler_number==(2 if BASE else 0)
assert mesh.area_faces.min()>1e-10
filename=f'{name}_80x25x10mm.stl'
mesh.export(OUT/filename)
loaded=trimesh.load_mesh(OUT/filename)
assert loaded.is_watertight and loaded.is_volume and loaded.is_winding_consistent
assert np.allclose(loaded.extents,[LENGTH,WIDTH,HEIGHT],atol=1e-5)
assert loaded.euler_number==(2 if BASE else 0)
# Cross section of the cavity at mid height must contain the exterior and opening.
section=loaded.section(plane_origin=[0,0,5],plane_normal=[0,0,1])
assert section is not None and len(section.discrete)==2
if BASE:
    section_base=loaded.section(plane_origin=[0,0,1],plane_normal=[0,0,1])
    assert section_base is not None and len(section_base.discrete)==1
report={'units':'mm','type':name,'dimensions_mm':loaded.extents.tolist(),
        'wall_thickness_mm':WALL,'base_thickness_mm':BASE,
        'nominal_inner_dimensions_mm':[LENGTH-2*WALL,WIDTH-2*WALL],
        'cavity_depth_mm':HEIGHT-BASE,'outer_corner_radius_mm':RADIUS,
        'edge_rounding_radius_mm':EDGE,'watertight':bool(loaded.is_watertight),
        'winding_consistent':bool(loaded.is_winding_consistent),'components':1,
        'euler_characteristic':int(loaded.euler_number),'triangles':len(loaded.faces),
        'volume_mm3':float(loaded.volume),'source':'Parametric approximation; user specified length 80 mm and base 2 mm. Other dimensions estimated.'}
(OUT/'validacao.json').write_text(json.dumps(report,indent=2)+'\n')

fig=plt.figure(figsize=(12,6),facecolor='#f6f7f9')
ax=fig.add_subplot(211)
p=contour(LENGTH,WIDTH,RADIUS,0)
q=contour(LENGTH-2*WALL,WIDTH-2*WALL,RADIUS-WALL,0)
ax.fill(p[:,0],p[:,1],color='#ddc4a5',ec='#9d8263',lw=1)
ax.fill(q[:,0],q[:,1],color='#f0dfc7' if BASE else '#f6f7f9',ec='#9d8263',lw=.8)
ax.annotate('',(-40,-17),(40,-17),arrowprops={'arrowstyle':'<->','color':'#333333'})
ax.text(0,-19,'80,00 mm',ha='center',va='top',fontsize=11)
ax.annotate('',(45,-12.5),(45,12.5),arrowprops={'arrowstyle':'<->','color':'#333333'})
ax.text(47,0,'25,00 mm',ha='left',va='center',fontsize=11)
ax.set_xlim(-48,61);ax.set_ylim(-24,18);ax.set_aspect('equal');ax.axis('off')
ax.set_title('Vista superior — '+('fundo fechado de 2 mm' if BASE else 'abertura passante'),fontsize=12)
ax=fig.add_subplot(212,projection='3d')
light=np.array([-.4,-.6,.8]);light/=np.linalg.norm(light)
illum=.70+.30*np.maximum(0,loaded.face_normals@light)
basecolor=np.array([.87,.76,.62])
colors=np.column_stack((illum[:,None]*basecolor,np.ones(len(illum))))
camera=np.array([np.cos(np.deg2rad(33))*np.cos(np.deg2rad(-65)),np.cos(np.deg2rad(33))*np.sin(np.deg2rad(-65)),np.sin(np.deg2rad(33))])
visible=loaded.face_normals@camera>1e-7
ax.add_collection3d(Poly3DCollection(loaded.triangles[visible],facecolors=colors[visible],linewidths=0,antialiaseds=False))
ax.set_xlim(-40,40);ax.set_ylim(-12.5,12.5);ax.set_zlim(0,10)
ax.set_box_aspect((80,25,10));ax.view_init(elev=33,azim=-65)
ax.set_axis_off();ax.set_title('80 × 25 × 10 mm · paredes de 3 mm · bordas arredondadas',fontsize=11)
# Increase 3D axes to make the model fill the lower half of the figure.
ax.set_position([.08,.01,.84,.48])
fig.savefig(OUT/'previa_stl.png',dpi=180,facecolor=fig.get_facecolor(),bbox_inches='tight');plt.close(fig)
(OUT/'LEIA-ME.txt').write_text(f'''{name.capitalize()} retangular com cantos arredondados.
Dimensões externas: 80,00 x 25,00 x 10,00 mm (comprimento x largura x altura).
Comprimento solicitado: 80,00 mm. Demais medidas estimadas pela imagem.
Paredes: 3,00 mm. Fundo: {BASE:.2f} mm. Profundidade interna: {HEIGHT-BASE:.2f} mm.
Espaço interno nominal: 74,00 x 19,00 mm, com cantos arredondados.
Raio externo dos cantos: 4,00 mm. Arredondamento das bordas: 0,60 mm.
Malha fechada, orientação consistente, volume positivo e uma única peça.
Importe em milímetros no fatiador. STL não armazena unidades.
Aproximação paramétrica da imagem; textura não reproduzida. Impressão física não testada.
''')
with ZipFile(OUT/f'{name}_80mm_arquivos.zip','w',ZIP_DEFLATED) as z:
    for f in [OUT/filename,OUT/'previa_stl.png',OUT/'LEIA-ME.txt',OUT/'validacao.json',Path(__file__)]:
        z.write(f,f.name)
print(json.dumps(report,indent=2))
